// Projects data - could later be replaced with database fetch
const projects = [
    {
        id: 1,
        title: "Sentiment Analysis Model",
        description: "Built a NLP model to classify product reviews with 89% accuracy",
        skills: ["Python", "NLTK", "Scikit-learn"],
        image: "assets/sentiment-analysis.jpg",
        github: "https://github.com/yourusername/sentiment-analysis"
    },
    {
        id: 2,
        title: "Sales Data Dashboard",
        description: "Interactive dashboard visualizing 2 years of sales data",
        skills: ["Python", "Pandas", "Plotly"],
        image: "assets/sales-dashboard.jpg",
        github: "https://github.com/yourusername/sales-dashboard"
    }
];

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    renderProjects();
    // Add other initialization code here
});

function renderProjects() {
    const container = document.getElementById('projects-container');
    
    projects.forEach(project => {
        const projectCard = document.createElement('div');
        projectCard.className = 'project-card';
        
        projectCard.innerHTML = `
            <img src="${project.image}" alt="${project.title}">
            <div class="project-content">
                <h3>${project.title}</h3>
                <p>${project.description}</p>
                <div class="project-skills">
                    ${project.skills.map(skill => `<span>${skill}</span>`).join('')}
                </div>
                <a href="${project.github}" target="_blank" class="project-link">View Code</a>
            </div>
        `;
        
        container.appendChild(projectCard);
    });
}